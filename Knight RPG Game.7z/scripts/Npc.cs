using Godot;
using System;

public partial class Npc : CharacterBody2D
{
    // The lines of text this specific NPC will say
    [Export]
    public string[] DialogueLines = {
        "Hello there, traveler!",
        "The slimes in the forest are getting restless.",
        "Stay safe on your journey!"
    };

    private AnimatedSprite2D _sprite;
    private bool _playerNearby = false;
    private bool _isTalking = false;

    public override void _Ready()
    {
        // Matches the name in your scene tree
        _sprite = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
        _sprite.Play("idle");

        // Set up the detection area
        Area2D interactionArea = GetNode<Area2D>("Interaction_Area");
        interactionArea.BodyEntered += OnBodyEntered;
        interactionArea.BodyExited += OnBodyExited;
    }

    public override void _Process(double delta)
    {
        // If player is close and presses 'Accept' (Space/Enter/E)
        if (_playerNearby && Input.IsActionJustPressed("ui_accept") && !_isTalking)
        {
            StartDialogue();
        }
    }

    private void StartDialogue()
    {
        _isTalking = true;

        // Play the 'talking' animation you created
        _sprite.Play("talking");

        // Locate the DialogueManager in your scene
        var dialogueManager = GetTree().Root.FindChild("DialogueManager", true, false) as DialogueManager;

        if (dialogueManager != null)
        {
            dialogueManager.StartDialogue(DialogueLines);
        }
        else
        {
            GD.PrintErr("Critical: DialogueManager node not found in the scene!");
            _isTalking = false;
            _sprite.Play("idle");
        }
    }

    private void OnBodyEntered(Node2D body)
    {
        // Use the name 'player' or check the script type
        if (body.Name.ToString().ToLower() == "player" || body is Player)
        {
            _playerNearby = true;
            GD.Print("Player reached NPC. Press Space/Enter to talk.");
        }
    }

    private void OnBodyExited(Node2D body)
    {
        if (body.Name.ToString().ToLower() == "player" || body is Player)
        {
            _playerNearby = false;
        }
    }

    // Call this function when the dialogue ends to reset the NPC
    public void EndDialogue()
    {
        _isTalking = false;
        _sprite.Play("idle");
    }
}