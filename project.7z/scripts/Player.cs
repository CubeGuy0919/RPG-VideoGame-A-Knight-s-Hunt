using Godot;

public partial class Player : CharacterBody2D
{
    [Export] public float MoveSpeed = 60f;
    [Export] public int MaxHP = 100;
    [Export] public int AttackDamage = 30;

    private AnimatedSprite2D sprite;
    private Area2D hitbox;

    private enum PlayerState { Idle, Move, Attack, Hurt, Dead }
    private PlayerState state = PlayerState.Idle;
    private float stateTimer = 0f;
    private Vector2 facingDirection = Vector2.Right;
    private int currentHP;

    public bool HasKey { get; private set; } = false;

    public override void _Ready()
    {
        sprite = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
        hitbox = GetNode<Area2D>("Hitbox");

        hitbox.Monitoring = false;
        currentHP = MaxHP;

        // NEW: This ensures we exit the attack state when the animation ends
        sprite.AnimationFinished += OnAnimationFinished;
    }

    public override void _Input(InputEvent e)
    {
        if (state == PlayerState.Dead || state == PlayerState.Hurt) return;

        // Check for "Attack" action and ensure we aren't already attacking
        if (e.IsActionPressed("Attack") && state != PlayerState.Attack)
        {
            EnterAttack();
        }
    }

    public override void _PhysicsProcess(double delta)
    {
        // If we are attacking or hurt, don't allow movement input
        if (state == PlayerState.Attack || state == PlayerState.Hurt)
        {
            // We still call MoveAndSlide(Vector2.Zero) to keep physics updated
            Velocity = Vector2.Zero;
            MoveAndSlide();
            return;
        }

        if (state == PlayerState.Dead) return;

        HandleMovement();
        MoveAndSlide();
    }

    private void EnterAttack()
    {
        GD.Print("[PLAYER] Attack Started");
        state = PlayerState.Attack;

        UpdateHitboxDirection();

        // NEW: Tell the Hitbox script to use the Player's AttackDamage value
        if (hitbox is HitBox playerHitBox)
        {
            playerHitBox.Damage = AttackDamage; // This sets it to 30
        }

        hitbox.Monitoring = true; 
        
        // As mentioned before, force a check for slimes already touching you
        if (hitbox is HitBox hb) hb.CheckForOverlap(); 

        sprite.FlipH = facingDirection.X < 0;
        sprite.Play("attack"); 
    }

    private void OnAnimationFinished()
    {
        if (sprite.Animation == "death")
        {
            GD.Print("[GAME OVER] Triggering screen...");
            ShowGameOverScreen();
        }
        else if (sprite.Animation == "hurt" || sprite.Animation == "attack")
        {
            ExitState();
        }
    }

    private void ShowGameOverScreen()
    {
        // You can reload the scene as a basic "Game Over"
        GetTree().ReloadCurrentScene();
        
        // OR if you have a UI node:
        // GetNode<Control>("/root/World/CanvasLayer/GameOverUI").Show();
    }

    private void ExitState()
    {
        hitbox.Monitoring = false;
        state = PlayerState.Idle;
        GD.Print("[PLAYER] Back to Idle");
    }

    private void HandleMovement()
    {
        Vector2 dir = Input.GetVector("ui_left", "ui_right", "ui_up", "ui_down");
        Velocity = dir * MoveSpeed;

        if (dir.X != 0) facingDirection = new Vector2(dir.X, 0);

        if (dir == Vector2.Zero)
        {
            state = PlayerState.Idle;
            if (sprite.Animation != "idle") sprite.Play("idle");
        }
        else
        {
            state = PlayerState.Move;
            PlayWalkAnimation(dir);
        }
    }

    private void PlayWalkAnimation(Vector2 dir)
    {
        if (dir.X != 0)
        {
            sprite.FlipH = dir.X < 0;
            sprite.Play("walk_right");
        }
        else
        {
            sprite.Play(dir.Y > 0 ? "walk_down" : "walk_up");
        }
    }

    private void UpdateHitboxDirection()
    {
        hitbox.Position = facingDirection.X > 0 ? new Vector2(16, 0) : new Vector2(-16, 0);
    }

public void TakeDamage(int amount)
{
    if (state == PlayerState.Dead) return;
    
    state = PlayerState.Hurt;
    Velocity = Vector2.Zero; // Stop moving when hit
    sprite.Play("hurt");
    GD.Print("[PLAYER] Playing Hurt Animation");
}

public void Die()
{
    state = PlayerState.Dead;
    Velocity = Vector2.Zero;
    hitbox.Monitoring = false;
    sprite.Play("death");
    GD.Print("[PLAYER] Playing Death Animation");
    GD.Print("[PLAYER] Dead");
}
    public void PickupKey() { HasKey = true; }
}