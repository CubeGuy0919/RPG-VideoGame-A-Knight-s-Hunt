using Godot;
using System.Collections.Generic;

public partial class DialogueManager : CanvasLayer
{
	private Label textLabel;
	private Panel panel;
	private List<string> lines = new List<string>();
	private int currentLineIndex = 0;
	private bool isActive = false;

	public override void _Ready()
	{
		panel = GetNode<Panel>("Panel");
		textLabel = GetNode<Label>("Panel/Label");
		panel.Visible = false; // Hide it at the start
	}

	public void StartDialogue(string[] newLines)
	{
		lines = new List<string>(newLines);
		currentLineIndex = 0;
		isActive = true;
		panel.Visible = true;
		ShowLine();
		
		// Pause the game if you want
		GetTree().Paused = true;
	}

	private void ShowLine()
	{
		textLabel.Text = lines[currentLineIndex];
	}

	public override void _Input(InputEvent @event)
	{
		if (isActive && @event.IsActionPressed("ui_accept")) // "Enter" or "Space"
		{
			currentLineIndex++;
			if (currentLineIndex < lines.Count)
			{
				ShowLine();
			}
			else
			{
				EndDialogue();
			}
		}
	}

	private void EndDialogue()
	{
		isActive = false;
		panel.Visible = false;
		GetTree().Paused = false;
	}
}
