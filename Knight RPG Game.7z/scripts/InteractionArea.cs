using Godot;

public partial class NPC : CharacterBody2D
{
	[Export] public string[] DialogueLines = { "Hello traveler!", "Watch out for those slimes!", "Good luck!" };
	private bool playerNearby = false;

	public override void _Ready()
	{
		GetNode<Area2D>("InteractionArea").BodyEntered += (body) => { if (body is Player) playerNearby = true; };
		GetNode<Area2D>("InteractionArea").BodyExited += (body) => { if (body is Player) playerNearby = false; };
	}

	public override void _Process(double delta)
	{
		if (playerNearby && Input.IsActionJustPressed("ui_accept"))
		{
			// Find the DialogueManager in the scene and start it
			var dialogueManager = GetTree().Root.GetNode<DialogueManager>("World/DialogueManager");
			dialogueManager.StartDialogue(DialogueLines);
		}
	}
}
